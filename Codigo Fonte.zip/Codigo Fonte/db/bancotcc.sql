-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 07-Nov-2018 às 00:24
-- Versão do servidor: 10.1.36-MariaDB
-- versão do PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bancotcc`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria`
--

CREATE TABLE `categoria` (
  `CategoriaId` int(5) NOT NULL,
  `UserId` int(5) NOT NULL,
  `DescricaoCategoria` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Nivel` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `categoria`
--

INSERT INTO `categoria` (`CategoriaId`, `UserId`, `DescricaoCategoria`, `Nivel`) VALUES
(2, 1, 'saúde', 2),
(3, 2, 'Salary', 1),
(4, 2, 'Alowance', 1),
(5, 2, 'Petty Cash', 1),
(6, 2, 'Bonus', 1),
(7, 2, 'Food', 2),
(8, 2, 'Social Life', 2),
(9, 2, 'Self-Development', 2),
(10, 2, 'Transportation', 2),
(11, 2, 'Culture', 2),
(12, 2, 'Household', 2),
(13, 2, 'Apparel', 2),
(14, 2, 'Beauty', 2),
(15, 2, 'Health', 2),
(16, 2, 'Gift', 2),
(19, 1, 'alimentação', 2),
(24, 1, 'Hora Extra', 1),
(25, 1, 'transporte', 2),
(27, 1, 'Escolar', 2),
(28, 1, 'Salario', 1),
(31, 1, 'Beleza', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `conta`
--

CREATE TABLE `conta` (
  `ContaId` int(5) NOT NULL,
  `UserId` int(5) NOT NULL,
  `NomeContaBanco` varchar(255) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `conta`
--

INSERT INTO `conta` (`ContaId`, `UserId`, `NomeContaBanco`) VALUES
(5, 2, 'Cash'),
(6, 2, 'Account'),
(7, 2, 'Card'),
(9, 1, 'Caixa - Corrente'),
(13, 1, 'Caixa - Poupança'),
(14, 1, 'NUBANK'),
(15, 1, 'Banco inter'),
(16, 1, 'Banco do Brasil');

-- --------------------------------------------------------

--
-- Estrutura da tabela `despesa`
--

CREATE TABLE `despesa` (
  `DespesaId` int(5) NOT NULL,
  `UserId` int(5) NOT NULL,
  `Titulo` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Vencimento` date NOT NULL,
  `CategoriaId` int(5) NOT NULL,
  `ContaId` int(5) NOT NULL,
  `Valor` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Descricao` text CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `despesa`
--

INSERT INTO `despesa` (`DespesaId`, `UserId`, `Titulo`, `Vencimento`, `CategoriaId`, `ContaId`, `Valor`, `Descricao`) VALUES
(2, 2, 'hdhsag', '2018-11-04', 7, 5, '10', ''),
(21, 1, 'gasolina', '2018-11-04', 25, 9, '50', ''),
(28, 1, 'cola branca', '2018-11-05', 27, 9, '5', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `receita`
--

CREATE TABLE `receita` (
  `ReceitaId` int(5) NOT NULL,
  `UserId` int(5) NOT NULL,
  `Titulo` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Date` date NOT NULL,
  `CategoriaId` int(5) NOT NULL,
  `ContaId` int(5) NOT NULL,
  `Valor` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Descricao` text CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `receita`
--

INSERT INTO `receita` (`ReceitaId`, `UserId`, `Titulo`, `Date`, `CategoriaId`, `ContaId`, `Valor`, `Descricao`) VALUES
(2, 2, 'HVVB', '2018-11-04', 3, 5, '900', ''),
(18, 1, 'Proinfo', '2018-11-04', 28, 13, '921', 'salario da loja'),
(26, 1, 'jhjh', '2018-11-06', 24, 9, '89', 'fds');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `UserId` int(5) NOT NULL,
  `Nome` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Sobrenome` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Email` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Senha` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Sexo` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`UserId`, `Nome`, `Sobrenome`, `Email`, `Senha`, `Sexo`) VALUES
(1, 'Jaqueline', 'Lopes Araujo', 'lopesjaque22@gmail.com', '0lHA9OTB3bpd6QUKkSFwlGIUhJw0xzvXrHgg67XL7UA=', 'Feminino'),
(2, 'Teste', 'Jaque', 'lopesjaque22@hotmail.com', '0lHA9OTB3bpd6QUKkSFwlGIUhJw0xzvXrHgg67XL7UA=', 'Feminino');

--
-- Acionadores `usuario`
--
DELIMITER $$
CREATE TRIGGER `GenerateDefaultAccount` AFTER INSERT ON `usuario` FOR EACH ROW INSERT INTO account (UserId, AccountName) VALUES (new.UserId, 'Cash'), (new.UserId, 'Account'), (new.UserId, 'Card')
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`CategoriaId`);

--
-- Indexes for table `conta`
--
ALTER TABLE `conta`
  ADD PRIMARY KEY (`ContaId`);

--
-- Indexes for table `despesa`
--
ALTER TABLE `despesa`
  ADD PRIMARY KEY (`DespesaId`),
  ADD KEY `fk_testt` (`ContaId`);

--
-- Indexes for table `receita`
--
ALTER TABLE `receita`
  ADD PRIMARY KEY (`ReceitaId`),
  ADD KEY `fk_test` (`ContaId`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`UserId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categoria`
--
ALTER TABLE `categoria`
  MODIFY `CategoriaId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `conta`
--
ALTER TABLE `conta`
  MODIFY `ContaId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `despesa`
--
ALTER TABLE `despesa`
  MODIFY `DespesaId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `receita`
--
ALTER TABLE `receita`
  MODIFY `ReceitaId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `UserId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `despesa`
--
ALTER TABLE `despesa`
  ADD CONSTRAINT `fk_testt` FOREIGN KEY (`ContaId`) REFERENCES `conta` (`ContaId`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `receita`
--
ALTER TABLE `receita`
  ADD CONSTRAINT `fk_test` FOREIGN KEY (`ContaId`) REFERENCES `conta` (`ContaId`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
