<?php

include('includes/db.php');
include('includes/FuncoesAuxiliar.php');
include('includes/plugin/email/PHPMailer.php');
include('includes/plugin/email/Exception.php');
include('includes/plugin/email/SMTP.php');
include('includes/plugin/email/POP3.php');

use PHPMailer\PHPMailer\PHPMailer;

$Email = $mysqli->real_escape_string($_POST['email']);

//passando configurações do meu email que está vinculado para fazer envio da senha por email

$sql = "Select * from usuario Where Email = '$Email'";
$c = mysqli_query($mysqli, $sql);
$user = mysqli_fetch_assoc($c);
$senha = "Select * from usuario Where Senha = '$Senha'";

$senha = ($user['Senha']);
if (mysqli_num_rows($c) >= 1) {
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'smtp.office365.com';
    $mail->SMTPAuth = true;
	$smtp_debug = true;
	$mail->smtp_debug = true;
    $mail->Username = 'lopesjaque22@hotmail.com';
    $mail->Password = 'Hulk1998*';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;
    $mail->IsHTML(true);
    $mail->From = $user['Email'];
    $mail->FromName = $user['Nome'];
    $mail->addAddress($user['Email']);

    $mail->Subject = 'SAGEF - LEMBRETE DE SENHA';

    $mail->Body = '<h4> Usuario ' . $user['Nome'] . '</h4><br><p>Segue a seguir sua senha no SAGEF :<b>' . $senha . '</b></p>';

    if ($mail->Send()):
        $msgBox = 'Enviado com sucesso !';
    else:
        $msgBox = 'Erro ao enviar Email:' . $mail->ErrorInfo;
    endif;

} else if ($Email != '')
    $msgBox = alertBox('Usuário Inexistente');

?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Gerenciador financeiro | Recuperar Senha</title>

    <!-- Bootstrap - CSS - script -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <script src="js/jquery-1.11.0.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/metisMenu.min.js"></script>
    <script src="js/sb-admin-2.js"></script>

</head>

<body class="login">

<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="logo-grande">
                <img src="logo/logoGrande.png"></img>
            </div>
            <div class="login-panel panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title text-center"><span
                                class="glyphicon glyphicon-lock"></span> <?php echo 'Recuperar Senha'; ?></h3>
                </div>
                <div class="panel-body">
                    <?php if ($msgBox) {
                        echo $msgBox;
                    } ?>
                    <form method="post" action="" role="form">
                        <fieldset>
                            <div class="form-group">
                                <label for="email"><?php echo 'Insira seu e-mail para recuperação de senha'; ?></label>
                                <p>Será enviado um link de recuperação de senha para este e-mail!</p>
                            </div>
                            <div class="form-group">
                                <label for="email"><?php echo 'E-mail'; ?></label>
                                <input class="form-control" id="email" placeholder="<?php echo 'E-mail'; ?>"
                                       name="email"
                                       type="text" value="">
                            </div>
                            <hr>
                            <button type="submit" name="login" class="btn btn-success btn-block"><span
                                        class="glyphicon glyphicon-log-in"></span> <?php echo 'Enviar'; ?></button>
                            <hr>
                            <a href="signUp.php"><span class="esquerda"> <?php echo 'Criar Conta?'; ?></span></a>

                            <a href="login.php"><span class="direita"><?php echo 'Possui uma conta?'; ?></span></a>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
</body>

</html>
