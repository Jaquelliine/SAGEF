<?php


$msgBox = '';

//Include 
include('includes/FuncoesAuxiliar.php');

include('includes/db.php');

//User Signup
if(isset($_POST['signup'])){
    if($_POST['email'] == '' || $_POST['nome'] == '' || $_POST['sobrenome'] == '' || $_POST['senha'] == '' || $_POST['rsenha'] == '') {
        $msgBox = alertBox($SignUpEmpty);
    } else if($_POST['senha'] != $_POST['rsenha']) {
        $msgBox = alertBox('Senhas não conferem! Verifique e tente novamente!');

    } else {
        // Set new account
        $Email 		= $mysqli->real_escape_string($_POST['email']);
        $Senha 	= $_POST['senha'];
        $Nome	= $mysqli->real_escape_string($_POST['nome']);
        $Sobrenome	= $mysqli->real_escape_string($_POST['sobrenome']);
        $Sexo	= $mysqli->real_escape_string($_POST['sexo']);

        //Check if already register

        $sql="Select Email from usuario Where Email = '$Email'";

        $c= mysqli_query($mysqli, $sql);

        if (mysqli_num_rows($c) >= 1) {

            $msgBox = alertBox('Email ou senha Incorretos');
        }
        else{

            // add new account
            $sql="INSERT INTO usuario (Nome, Sobrenome, Email, Senha, Sexo) VALUES (?,?,?,?,?)";
            if($statement = $mysqli->prepare($sql)){
                //bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
                $statement->bind_param('sssss', $Nome, $Sobrenome, $Email, $Senha, $Sexo);
                $statement->execute();
            }
            $msgBox = alertBox('Conta criada com sucesso');
        }
    }
}

?>




<!DOCTYPE html>
<html lang="pt-Br">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Gerenciador financeiro | Cadastro</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>

<body class="cadastro">

<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="logo-grande">
                <img src="logo/logoGrande.png"></img>
            </div>
            <div class="login-panel panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title text-center"><span class="glyphicon glyphicon-lock"></span> <?php  echo 'Criar conta'; ?></h3>
                </div>
                <div class="panel-body">
                    <?php if ($msgBox) { echo $msgBox; } ?>
                    <form method="post" action="" role="form">
                        <fieldset>
                            <div class="form-group col-lg-6">
                                <label for="email"><?php  echo 'E-mail'; ?></label>
                                <input class="form-control"  placeholder="<?php  echo 'E-mail'; ?>" name="email" type="email" autofocus>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="email"><?php  echo 'Nome'; ?></label>
                                <input class="form-control"  placeholder="<?php  echo 'Nome'; ?>" name="nome" type="text" >
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="email"><?php  echo 'Sobrenome'; ?></label>
                                <input class="form-control"  placeholder="<?php  echo 'Sobrenome'; ?>" name="sobrenome" type="text" >
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="email"><?php  echo 'Sexo'; ?></label>
                                <select class="form-control bold"  name="sexo">
                                    <option value="Feminino">Feminino</option>
                                    <option value="Masculino">Masculino</option></select>

                                </select>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="senha"><?php  echo 'Senha'; ?></label>
                                <input class="form-control"  placeholder="<?php  echo 'Senha'; ?>" name="senha" type="password" value="">
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="senha"><?php  echo 'Repita a senha'; ?></label>
                                <input class="form-control"  placeholder="<?php  echo 'Repita a senha'; ?>" name="rsenha" type="password" value="">
                            </div>
                            <hr>
                            <button type="submit" name="signup" class="btn btn-success btn-block"><span class="glyphicon glyphicon-log-in"></span>  <?php  echo 'Cadastrar'; ?></button>                                 <hr>

                        </fieldset>
                        <a href = "login.php"><span class="direita"><?php echo 'Possui uma conta?';?></span></a>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- jQuery Version 1.11.0 -->
<script src="js/jquery-1.11.0.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="js/plugins/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="js/sb-admin-2.js"></script>

</body>

</html>
