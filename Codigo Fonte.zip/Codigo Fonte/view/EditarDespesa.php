<?php


//Include 
include('includes/FuncoesAuxiliar.php');

//pega o id
if(isset($_GET['id'])){
$DespesaId = abs($_GET['id']);

//seleciona os dados do id selecionada
if($DespesaId != ''){
		$EditarDespesa = "SELECT a.DespesaId, a.Titulo, a.Vencimento, a.Valor, a.Descricao, c.DescricaoCategoria, c.CategoriaId, ac.ContaId, ac.NomeContaBanco from despesa a, categoria c, conta ac where a.CategoriaId = c.CategoriaId 
					AND a.ContaId = ac.ContaId AND c.Nivel = 2 AND a.UserId = $UserId AND a.DespesaId = $DespesaId";
					
		if($DespesaEdit = mysqli_query($mysqli,$EditarDespesa)){
			$row = mysqli_fetch_assoc($DespesaEdit);
		}
	}
}
	else{exit;}
// Edita os dados da despesa selecionada
if(isset($_POST['despesa'])){
		$DespesaId		= $row['DespesaId'];
		$iuser			= $_SESSION['UserId'];
		$ititulo 			= $mysqli->real_escape_string($_POST["ititulo"]);
		$icategoria		= $mysqli->real_escape_string($_POST["icategoria"]);
		$iconta		= $mysqli->real_escape_string($_POST["iconta"]);
		$idescricao	= $mysqli->real_escape_string($_POST["idescricao"]);
		$idate			= $mysqli->real_escape_string($_POST["idate"]);
		$ivalor		= $mysqli->real_escape_string(clean($_POST["ivalor"]));
		
		// altera no banco de dados
		$sql="UPDATE despesa SET Titulo = ?, Vencimento = ?, CategoriaId = ?, ContaId = ?, Valor = ?, Descricao = ? WHERE DespesaId = $DespesaId";
		if($statement = $mysqli->prepare($sql)){
			$statement->bind_param('ssiiss', $ititulo, $idate, $icategoria, $iconta, $ivalor, $idescricao);	
			$statement->execute();
			
		}
		$msgBox = alertBox('Alterado com sucesso!');
	}	
	
// pega a nova data depois de feita a alteração	
$EditarDespesa = "SELECT a.DespesaId, a.Titulo, a.Vencimento, a.Valor, a.Descricao, c.DescricaoCategoria, c.CategoriaId, ac.ContaId, ac.NomeContaBanco from despesa a, categoria c, conta ac where a.CategoriaId = c.CategoriaId 
					AND a.ContaId = ac.ContaId AND c.Nivel = 2 AND a.UserId = $UserId AND a.DespesaId = $DespesaId";
		if($DespesaEdit = mysqli_query($mysqli,$EditarDespesa)){
			$row = mysqli_fetch_assoc($DespesaEdit);
		}
	
?>        
        
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
				    <h1 class="page-header"><?php echo 'Editar Despesa' ;?></h1>
                </div>
            </div>
			<?php if ($msgBox) { echo $msgBox; } ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                           <i class="fa fa-minus"></i> <?php echo 'Despesa' ;?>
                        </div>
                            <div class="panel-body">
                                <form role="form" method="post" action="">
                                    <fieldset>
                                    <div class="form-group col-lg-6">
								        <label for="ititulo"><?php echo 'Titulo' ;?></label>
                                        <input class="form-control" required placeholder="<?php echo 'Titulo' ;?>" value="<?php echo $row['Titulo'];?> " name="ititulo" type="text" autofocus>
                                    </div>
                                    
                                    <div class="form-group col-lg-6">
										 <label for="ivalor" class="control-label"><?php echo 'Valor' ;?></label> 
											 <div class="input-group">                                 
												 <input class="form-control" required placeholder="<?php echo 'Valor' ;?>" value="<?php echo number_format($row['Valor']);?>" id="ivalor" name="ivalor" type="text" value="">
											 </div>
									</div>
									<div class="form-group col-lg-6">
                                        <label for="icategoria"><?php echo 'Categoria' ;?></label>
                                        <select name="icategoria" class="form-control">
											<option value="<?php echo $row['CategoriaId'];?>" select="selected"><?php echo $row['DescricaoCategoria'];?></option>
											<?php while($col = mysqli_fetch_assoc($despesa)){ ?>
                                            <option value="<?php echo $col['CategoriaId'];?>"><?php echo $col['DescricaoCategoria'];?></option>
                                            <?php } ?>
                                        </select>
                                    </div>                             
									<div class="form-group col-lg-6">
                                         <label for="iconta"><?php echo 'Conta' ;?></label>
											<select name="iconta" class="form-control">
											<option value="<?php echo $row['ContaId'];?>" select="selected"><?php echo $row['NomeContaBanco'];?></option>
                                            <?php while($col = mysqli_fetch_assoc($ContaReceita)){ ?>
                                            <option value="<?php echo $col['ContaId'];?>"><?php echo $col['NomeContaBanco'];?></option>
                                            <?php } ?>
											</select>
									</div>
									
									
									 <div class="form-group col-lg-6">
								        <label for="idescricao"><?php echo 'Data' ;?></label>
                                        <input name="idate" class="form-control" type="date"  value="<?php echo date ("d-m-Y");?>">
										</input>
								   </div>
									
                                    <div class="form-group col-lg-6">
								        <label for="idescricao"><?php echo 'Descrição' ;?></label>
                                        <input class="form-control"  required placeholder="<?php echo 'Descrição' ;?>" name="idescricao" type="text" autofocus>
                                    </div>
									</fieldset>
									<div class="form-group col-lg-3 col-md-6">
										<button type="submit" name="despesa" class="btn btn-warning btn-block "><span class="glyphicon glyphicon-log-in"></span>  <?php echo'Salvar' ;?></button>
									</div>
								</form>
                            </div>
                     </div>
                </div>
            </div>
         </div>
 <script>
$(document).on('keyup', '#ivalor', function() {
    var x = $(this).val();
    $(this).val(x.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ","));
});
 </script>

