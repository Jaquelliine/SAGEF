<?php

//Include 
include('includes/FuncoesAuxiliar.php');

//Verifica os dados
if(isset($_POST['despesa'])){
		$euser			= $_SESSION['UserId'];
		$etitulo 			= $mysqli->real_escape_string($_POST["etitulo"]);
		$ecategoria		= $mysqli->real_escape_string($_POST["ecategoria"]);
		$econta		= $mysqli->real_escape_string($_POST["econta"]);
		$edescricao	= $mysqli->real_escape_string($_POST["edescricao"]);
		$edate			= $mysqli->real_escape_string($_POST["edate"]);
		$evalor		= $mysqli->real_escape_string(clean($_POST["evalor"]));
		//verifica se o titulo e valor foram preenchidos
        if($etitulo == '' OR $evalor == '' ) {
                $msgBox = alertBox('Titulo ou valor não preenchidos. Favor preencha os campos!');
            } else{
		//valor nao pode ser menor que zero 
		if($evalor < 0){
            $msgBox = alertBox('Valor menor que zero');
        }else{
		//insere no banco se tiver cumprido os requisitos
		$sql="INSERT INTO despesa (UserId, Titulo, Vencimento, CategoriaId, ContaId, Valor, Descricao) VALUES (?,?,?,?,?,?,?)";
		if($statement = $mysqli->prepare($sql)){
			$statement->bind_param('issiiss',$euser, $etitulo, $edate, $ecategoria, $econta, $evalor, $edescricao);	
			$statement->execute();
		}
		$msgBox = alertBox('Salvo com sucesso!');
        }
	}
}

?>        
        
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
				    <h1 class="page-header"><?php echo 'Nova Despesa' ;?></h1>
                </div>
            </div>
			<?php if ($msgBox) { echo $msgBox; } ?>
            <div class="row">                 
                <div class="col-lg-12 ">
		            <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-minus"></i> <?php echo 'Despesas' ;?>
                        </div>
                            <div class="panel-body">
                                <form action="" method="post" role="form">
                                    <fieldset>
                                    <div class="form-group col-lg-6">
                                        <label for="etitulo"><?php echo 'Titulo' ;?></label>
                                        <input class="form-control" required placeholder="<?php echo 'Titulo' ;?>" name="etitulo" type="text" autofocus>
                                    </div>
                                    <div class="form-group col-lg-5">
										 <label for="evalor" class="control-label"><?php echo 'Valor' ;?></label> 
											 <div class="input-group">
												 <input class="form-control" required placeholder="<?php echo 'Valor' ;?>"  id="ivalor" name="evalor" type="text" value="">
											 </div>
									</div>
									<div class="form-group  col-lg-6">
                                        <label for="ecategoria"><?php echo 'Categoria' ;?></label>
                                        <select name="ecategoria" class="form-control">
                                            <?php while($col = mysqli_fetch_assoc($despesa)){ ?>
                                            <option value="<?php echo $col['CategoriaId'];?>"><?php echo $col['DescricaoCategoria'];?></option>
                                            <?php } ?>
                                        </select>
                                    </div>                                 
									<div class="form-group  col-lg-4">
                                         <label for="econta"><?php echo 'Conta' ;?></label>
                                        <select name="econta" class="form-control">
                                             <?php while($col = mysqli_fetch_assoc($ContaReceita)){ ?>
                                            <option value="<?php echo $col['ContaId'];?>"><?php echo $col['NomeContaBanco'];?></option>
                                            <?php } ?>
                                        </select>
									 </div>
									 
									 <div class="form-group  col-lg-4">
                                         <label for="econta"><?php echo 'Vencimento' ;?></label>
                                        <input name="edate" class="form-control" type="date"  value="<?php echo date("d-m-Y");?>">
										</input>
									 </div>
									 
									
									
									
									
                                    <div class="form-group col-lg-6">
								        <label for="edescricao"><?php echo 'Descição' ;?></label>
                                        <input class="form-control"  required placeholder="<?php echo 'Descrição' ;?>" name="edescricao" type="text" autofocus>
                                    </div>                             
									</fieldset>
                            </div>
									<div class="panel-footer">
										<button type="submit" name="despesa" class="btn btn-warning btn-block"><span class="glyphicon glyphicon-log-in"></span>  <?php echo 'Salvar' ;?></button>
								</form>
									</div>
                    </div>
                </div>
                 
            </div>
         </div>
 <script>
$(document).on('keyup', '#ivalor', function() {
    var x = $(this).val();
    $(this).val(x.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ","));
});
 </script>