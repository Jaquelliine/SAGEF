<?php

//Include 
include('includes/FuncoesAuxiliar.php');
include ('includes/global.php');

// Soma todos rendimento
$GetTodasReceitas 	 = "SELECT SUM(Valor) AS Valor FROM receita WHERE UserId = $UserId";
$GetAReceita		 = mysqli_query($mysqli, $GetTodasReceitas);
$ReceitaCol 		 = mysqli_fetch_assoc($GetAReceita);

// Soma todas as despesas
$GetTodasDespesa   = "SELECT SUM(Valor) AS Valor FROM despesa WHERE UserId = $UserId";
$GetADespesa         = mysqli_query($mysqli, $GetTodasDespesa);
$DespesaCol          = mysqli_fetch_assoc($GetADespesa);

//Calcula a diferença entre os rendimentos e as despesas, sendo este o saldo atual 
$CountTotal = $ReceitaCol['Valor'] - $DespesaCol['Valor'];

//Lista os rendimentos recentes
$GetResumoReceita = "SELECT * from receita left join categoria on receita.CategoriaId = categoria.CategoriaId left join conta on receita.ContaId = conta.ContaId where receita.UserId = $UserId ORDER BY receita.Date DESC LIMIT 10";
$ResumoReceita = mysqli_query($mysqli,$GetResumoReceita); 

//Lista as despesas recentes
$GetResumoDespesa = "SELECT * from despesa left join categoria on despesa.CategoriaId = categoria.CategoriaId left join conta on despesa.ContaId = conta.ContaId where despesa.UserId = $UserId ORDER BY despesa.Vencimento DESC LIMIT 10";
$ResumoDespesa = mysqli_query($mysqli,$GetResumoDespesa); 

function geraGrafico($largura, $altura, $valores, $referencias, $tipo = "p3"){
           $valores = implode(',', $valores);
           $referencias = implode('|', $referencias);
 
           return "http://chart.apis.google.com/chart?chs=". $largura ."x". $altura . "&amp;chd=t:" . $valores . "&amp;cht=p3&amp;chl=" . $referencias;
     }
	 


// Buscar renda pela data das receitas
if (isset($_POST['buscarbtndata'])) {
	$dataincial=$_POST['buscardatainicio'];
	$datafinal=$_POST['buscardatafim'];
	$GetResumoReceita = "SELECT * from receita left join categoria on receita.CategoriaId = categoria.CategoriaId left join conta on receita.ContaId = conta.ContaId
							WHERE receita.UserId = $UserId AND Date BETWEEN '$dataincial' AND '$datafinal'";
	$ResumoReceita = mysqli_query($mysqli,$GetResumoReceita); 
	
}


// Buscar renda pela data das despesas
if (isset($_POST['buscarbtndata'])) {
	$dataincial=$_POST['buscardatainicio'];
	$datafinal=$_POST['buscardatafim'];
	$GetResumoDespesa = "SELECT * from despesa left join categoria on despesa.CategoriaId = categoria.CategoriaId left join conta on despesa.ContaId = conta.ContaId
							WHERE despesa.UserId = $UserId AND Vencimento BETWEEN '$dataincial' AND '$datafinal'";
	$ResumoDespesa = mysqli_query($mysqli,$GetResumoDespesa); 
	


}
	 
?>



	<div id="page-wrapper">
	<?php if ($msgBox) { echo $msgBox; } ?>
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header"><?php echo 'Painel Resumo';?></h1>
				<div class="pull-right">
								<form name="form1" action="" method="post">
								<div class="form-group input-group col-lg-2	pull-left">
                                     De:<input type="date" name="buscardatainicio" title="Data Inicial"  class="form-control" placeholder="Data Inicio"/>
                                </div>
								<div class="form-group input-group col-lg-2	pull-right">
                                     Até:<input type="date"  name="buscardatafim" title="Data Final" class="form-control" placeholder="Data Final"/>
									<span class="input-group-btn">
									<p> </p>
									<p> </br> </p>
									<button onclick="return validar()" class="btn btn-primary" name="buscarbtndata" type="input"><i class="fa fa-search"></i></button>
                                     
									 </span>
									 
							   </div>
                                </form> 
            </div>

            </div>
			
        </div>
		<!-- div que separa as tres colunas de saldo , receita, despesa e conta -->
            <div class="row">
				<!-- despesa total-->
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="glyphicon glyphicon-resize-full fa-4x"></i>
                                </div>
                                <div class="col-xs-12 text-left">
								
								 <h2><?php echo 'R$'.' '.number_format($DespesaCol['Valor'],2,',','.');?> </h2>
								
                                    <div><?php echo 'Despesa Total';?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<!-- fim da despesa total>
				
				<!--saldo total-->
            <div class="col-lg-3 col-md-6">
                <div class="panel panel-green">
                    <div class="panel-heading">
                         <div class="row">
                            <div class="col-xs-1">
                                <i class="glyphicon glyphicon-resize-small fa-4x"></i>
                            </div>
                            <div class="col-xs-12 text-left">
                                <h2><?php echo 'R$'.' '.number_format($CountTotal,2,',','.');?> </h2>
                                <div><?php echo 'Saldo Total';?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
				<!-- fim do saldo total-->
				<!-- saldo em contas-->
				<div class="col-lg-6 col-md-6">
					<div class="panel panel-primary">
						<div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> <?php echo 'Saldo em Contas' ?>
                        </div>
						<div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                    <table class="table table-bordered table-hover table-striped">
                                        <thead>
                                        <tr>
                                            <th><?php echo 'Conta/Banco';?></th>
                                            <th><?php echo 'Valor';?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php while($col = mysqli_fetch_assoc($Dount)){ ?>
                                            <tr>
                                                <td><?php echo $col['NomeContaBanco'];?></td>
												
												
                                                <td class="text-right"><?php echo 'R$'.number_format($col['Valor'],2,',','.');?></td>
                                            </tr>
                                               <?php } ?>   
                                        </tbody>
                                    </table>
									</div>
								</div>
                            </div>
						</div>
					</div>
				</div>
				<!-- fim saldo em contas-->
				
            </div>
			<!-- fim do bloco de saldos-->
			
			
            <!-- bloco com rendimentos e despesas mais recentes -->
            <div class="row">
			<!-- rendimentos mais recentes-->
			
			<div class="col-lg-12">
			<div id="tabelareceitadespesa">
			
			
                <div class="col-lg-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> <?php echo 'Últimos Rendimentos';?>
                            
                        </div>
                        <div class="panel-body">
                           <div class="">
								<div class="table-responsive">
                                        <table class="table table-bordered table-hover table-striped">
                                            <thead>
                                                <tr>
                                                    <th><?php echo 'Título';?></th>
                                                    <th><?php echo 'Data';?></th>
                                                    <th><?php echo 'Conta/Banco';?></th>
                                                    <th><?php echo 'Valor';?></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while($col = mysqli_fetch_assoc($ResumoReceita)){ ?>
												<tr>
													<td><?php echo $col['Titulo'];?></td>
													<td><?php echo date("d/m/Y",strtotime($col['Date']));?></td>
													<td><?php echo $col['NomeContaBanco'];?></td>
													
													<td><?php echo 'R$'.' '.number_format($col['Valor'],2,',','.');?></td>
													

												</tr>
                                               <?php } ?>   
                                            </tbody>
											
                                        </table>
										<table align="right" >
									<tr >
									<td ><?php echo 'TOTAL:'.' '.'R$'.' '.number_format($ReceitaCol['Valor'],2,',','.')?> </td>
									
									</tr>
								</table>
								</div>
                           </div>
                        </div>
                    </div>
                </div>
				</div>
				<!-- fim das receitas recentes-->
				
                <!-- Despesas recentes -->
                <div class="col-lg-6">
					<div class="panel panel-red">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> <?php echo 'Últimas Despesas';?>
                        </div>
                        <div class="panel-body">
						<div class="">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover table-striped">
                                        <thead>
                                                <tr>
                                                    <th><?php echo 'Titulo';?></th>
                                                    <th><?php echo 'Vencimento';?></th>
                                                    <th><?php echo 'Conta/Banco';?></th>
                                                    <th><?php echo 'Valor';?></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                 <?php while($cols = mysqli_fetch_assoc($ResumoDespesa)){ ?>
                                                <tr>
                                                    <td><?php echo $cols['Titulo'];?></td>
                                                    <td><?php echo date("d/m/Y",strtotime($cols['Vencimento']));?></td>
                                                    <td><?php echo $cols['NomeContaBanco'];?></td>
                                                    <td><?php echo 'R$'.' '.number_format($cols['Valor'],2,',','.')?></td>
                                                </tr>
                                               <?php } ?>   
                                            </tbody>
                                        </table>
										<table align="right" >
									<tr > 
									<td ><?php echo 'TOTAL:'.' '.'R$'.' '.number_format($DespesaCol['Valor'],2,',','.')?> </td>
									</tr>
								</table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
          </div>
		  </div>
</div>
		  
			<div id="tabela">
                 <div class="col-lg-6" >
                    <!-- /.panel -->
                    <div class="panel panel-primary">
                        <div class="panel-heading" >
                            <i class="fa fa-bar-chart-o fa-fw"></i> <?php echo 'Gráfico Receita X Despesa deste mês'; ?>
							<input  type="image" title="Imprimir" src="img/btnbaixar.png"  id="btnImprimir" onclick="CriaPDF()"/>
                        
						</div>
                        <div class="panel-body">
                            <div id="bymonth"></div> 
                            <?php $grafico = geraGrafico(480, 180, array($DespesaCol['Valor'], number_format($ReceitaCol['Valor'],2,',','.')), array('Despesas R$ '.number_format($DespesaCol['Valor'],2,',','.'), 'Receitas R$ '.number_format($ReceitaCol['Valor'],2,',','.'))) ?>
							<img src="<?php echo $grafico ?>" title="Grafico de receitas x despesas" />
                       
                        </div>
                    </div>
                </div>
			</div>
			
			
		</div>	
    </div>
	
</body>
</html>
<script>
function validar() { 
	var buscardatainicio = form1.buscardatainicio.value; 
	var buscardatafim = form1.buscardatafim.value;
	if (buscardatafim == "") { 
	alert('Preencha o intervalo de datas!');
	location.href='index.php';
	form1.buscardatafim.focus();
	return false;
 } 
	if (buscardatainicio == "") { 
	alert('Preencha o intervalo de datas!');
	location.href='index.php';
	form1.buscardatainicio.focus();
	return false;
 } 
 if (buscardatainicio > buscardatafim) { 
	alert('Data inicial não pode ser maior que a data final!');
	location.href='index.php';
	form1.buscardatainicio.focus();
	return false;
 } 
 if (buscardatafim < buscardatainicio) { 
	alert('Data final não pode ser menor que a data inicial!');
	location.href='index.php';
	form1.buscardatainicio.focus();
	return false;
 } 
 
}

function CriaPDFRD() {
        var minhaTabela = document.getElementById('tabelareceitadespesa').innerHTML;

        var style = "<style>";
        style = style + "table {width: 100%;font: 20px Calibri;}";
        style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";

        // CRIA UM OBJETO WINDOW
        var win = window.open('', '', 'height=700,width=700');

        win.document.write('<html><head>');
        win.document.write('<title>Relatório de Despesas</title>');   // <title> CABEÇALHO DO PDF.
        win.document.write(style);                                     // INCLUI UM ESTILO NA TAB HEAD
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(minhaTabela);                          // O CONTEUDO DA TABELA DENTRO DA TAG BODY
        win.document.write('</body></html>');

        win.document.close(); 	                                         // FECHA A JANELA

        win.print();                                                            // IMPRIME O CONTEUDO
    }

function CriaPDF() {
        var minhaTabela = document.getElementById('tabela').innerHTML;

        var style = "<style>";
        style = style + "table {width: 100%;font: 20px Calibri;}";
        style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";

        // CRIA UM OBJETO WINDOW
        var win = window.open('', '', 'height=700,width=700');

        win.document.write('<html><head>');
        win.document.write('<title>Relatório de Despesas</title>');   // <title> CABEÇALHO DO PDF.
        win.document.write(style);                                     // INCLUI UM ESTILO NA TAB HEAD
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(minhaTabela);                          // O CONTEUDO DA TABELA DENTRO DA TAG BODY
        win.document.write('</body></html>');

        win.document.close(); 	                                         // FECHA A JANELA

        win.print();                                                            // IMPRIME O CONTEUDO
    }
</script>
