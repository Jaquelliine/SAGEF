<?php

//Include 
include('includes/FuncoesAuxiliar.php');
include ('includes/global.php');

$BuscarTermo = '';
// escluir despesa
if (isset($_GET['DespesaId'])) {
	// pega pelo id da despesa selecionada
		$DespesaId = $_GET['DespesaId'];	
		//realiza exclusão no banco de dados
		$Delete = "DELETE FROM despesa WHERE DespesaId = $DespesaId";
		$DeleteI = mysqli_query($mysqli,$Delete); 
		$msgBox = alertBox('Item excluido!');
	}
	
//Relatório das despesas no histórico
$GetResumoDespesa = "SELECT * from despesa left join categoria on despesa.CategoriaId = categoria.CategoriaId left join conta on despesa.ContaId = conta.ContaId where despesa.UserId = $UserId ORDER BY despesa.Vencimento DESC";
$ResumoDespesa = mysqli_query($mysqli,$GetResumoDespesa); 

// Soma todas as despesas
$GetTodasDespesa   = "SELECT SUM(Valor) AS Valor FROM despesa WHERE UserId = $UserId";
$GetADespesa         = mysqli_query($mysqli, $GetTodasDespesa);
$DespesaCol          = mysqli_fetch_assoc($GetADespesa);



// Buscar renda pela data.
	
	
if (isset($_POST['buscarbtndata'])){
	
	$dataincial=$_POST['buscardatainicio'];
	$datafinal=$_POST['buscardatafim'];
	$GetResumoDespesa = "SELECT * from despesa left join categoria on despesa.CategoriaId = categoria.CategoriaId left join conta on despesa.ContaId = conta.ContaId
							WHERE despesa.UserId = $UserId AND Vencimento BETWEEN '$dataincial' AND '$datafinal'";
	$ResumoDespesa = mysqli_query($mysqli,$GetResumoDespesa); 
	}
	
?>
<title>Relatório de Despesas</title>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo 'Resumo de Despesas'; ?></h1>
                </div>
            </div>
			<?php if ($msgBox) { echo $msgBox; } ?>
			<div class="pull-right">
								<form name="form1" action="" method="post">
								<div class="form-group input-group col-lg-2	pull-left">
                                     De:<input type="date" name="buscardatainicio" title="Data Inicial"  class="form-control" placeholder="Data Inicio"/>
                                </div>
								<div class="form-group input-group col-lg-2	pull-right">
                                     Até:<input type="date"  name="buscardatafim" title="Data Final" class="form-control" placeholder="Data Final"/>
									<span class="input-group-btn">
									
									<p> </p>
									<p> </br> </p>
									<button onclick="return validar()" class="btn btn-primary" name="buscarbtndata" type="input"><i class="fa fa-search"></i></button>
                                     
									 </span>
									 
							   </div>
                                </form> 
            </div>
							
				<a href="index.php?page=NovaDespesa" class="btn white btn-success "><i class="fa fa-plus"></i> <?php echo 'Novo'; ?></a>
				<input type="button" class="btn white btn-success" value="Imprimir" id="btnImprimir" onclick="CriaPDF()"/>

				<div class="row">
				<div id="tabela">
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                           <i class="glyphicon glyphicon-list-alt"></i> <?php echo 'Histórico de Despesas'; ?>
                        </div>
                        <div class="panel-body">
						
						
						    
                            <div class="">
														
							
                                <table class="table table-bordered table-hover table-striped">
                                    <thead>
									
									<tr>
										<th class="text-left"><?php echo 'Titulo'; ?></th>
										<th class="text-left"><?php echo 'Data'; ?></th>
										<th class="text-left"><?php echo 'Categoria'; ?></th>
										<th class="text-left"><?php echo 'Conta'; ?></th>
										<th class="text-left"><?php echo 'Descrição'; ?></th>
										<th class="text-left"><?php echo 'Valor'; ?></th>
									</tr>
									</thead>
									<tbody>
									<?php while($col = mysqli_fetch_assoc($ResumoDespesa)){ ?>
									<tr>
										<td><?php echo $col['Titulo'];?></td>
										<td><?php echo date("d/m/Y",strtotime($col['Vencimento']));?></td>
										<td><?php echo $col['DescricaoCategoria'];?></td>
										<td><?php echo $col['NomeContaBanco'];?></td>
										<td><?php echo $col['Descricao'];?></td>
										<td><?php echo 'R$ '.number_format($col['Valor'],2,',','.');?></td>
										
										<td  class="notification">
										<a href="index.php?page=EditarDespesa&id=<?php echo $col['DespesaId'];?>" class="" data-toggle="modal"><span class="btn btn-primary btn-xs glyphicon glyphicon-edit" data-toggle="tooltip" data-placement="left" title="" data-original-title="<?php echo 'Editar'; ?>"></span></a>
										<a href="javascript:ExcluiRegistro(<?php echo $col['DespesaId'];?>);"  data-toggle="modal"><span class=" glyphicon glyphicon-trash btn btn-primary btn-xs" data-toggle="tooltip" data-placement="right" title="" data-original-title="<?php echo 'Excluir'; ?>"></span></button>			
										</td>
									</tr>
									
									</tbody>
								
                          								
	                		 <?php } ?>   
					
									
								</table>
								<table align="right" >
									<tr >
									<td ><?php echo 'TOTAL:'.' '.'R$'.' '.number_format($DespesaCol['Valor'],2,',','.').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'?> </td>
									</tr>
								</table>
								</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script>
	function ExcluiRegistro(reg){
		confirm("Deseja excluir esse registro?");
		if (true) {
			location.href='index.php?page=ResumoDespesas&DespesaId='+reg;
		 }
		
	}
	
	function validar() { 
	var buscardatainicio = form1.buscardatainicio.value; 
	var buscardatafim = form1.buscardatafim.value;
	if (buscardatafim == "") { 
	alert('Preencha o intervalo de datas!');
	location.href='index.php?page=ResumoDespesas';
	form1.buscardatafim.focus();
	return false;
 } 
	if (buscardatainicio == "") { 
	alert('Preencha o intervalo de datas!');
	location.href='index.php?page=ResumoDespesas';
	form1.buscardatainicio.focus();
	return false;
 } 
 if (buscardatainicio > buscardatafim) { 
	alert('Data inicial não pode ser maior que a data final!');
	location.href='index.php?page=ResumoDespesas';
	form1.buscardatainicio.focus();
	return false;
 } 
 if (buscardatafim < buscardatainicio) { 
	alert('Data final não pode ser menor que a data inicial!');
	location.href='index.php?page=ResumoDespesas';
	form1.buscardatainicio.focus();
	return false;
 } 
 
}

    function CriaPDF() {
        var minhaTabela = document.getElementById('tabela').innerHTML;

        var style = "<style>";
        style = style + "table {width: 100%;font: 20px Calibri;}";
        style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";

        // CRIA UM OBJETO WINDOW
        var win = window.open('', '', 'height=700,width=700');

        win.document.write('<html><head>');
        win.document.write('<title>Relatório de Despesas</title>');   // <title> CABEÇALHO DO PDF.
        win.document.write(style);                                     // INCLUI UM ESTILO NA TAB HEAD
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(minhaTabela);                          // O CONTEUDO DA TABELA DENTRO DA TAG BODY
        win.document.write('</body></html>');

        win.document.close(); 	                                         // FECHA A JANELA

        win.print();                                                            // IMPRIME O CONTEUDO
    }

</script>	
