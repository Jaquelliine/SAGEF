<?php

//Include 
include('includes/FuncoesAuxiliar.php');
include ('includes/global.php');

//Excluindo categoria
if(isset($_POST['submitin'])){
		$CategoriaIds = $_POST['categoriaid'];
		$Delete = "DELETE FROM categoria WHERE CategoriaId = $CategoriaIds";
		$DeleteI = mysqli_query($mysqli,$Delete); 
		
		$msgBox = alertBox('Categoria excluida');
	}

//Editando categoria
if(isset($_POST['edit'])){
		$CategoriaIds = $_POST['categoriaid'];
		$DescricaoCategoria = $_POST['categoriaedit'];
		$sql="Select DescricaoCategoria from categoria Where DescricaoCategoria = '$DescricaoCategoria'";
		$c= mysqli_query($mysqli, $sql);
		if (mysqli_num_rows($c) >= 1) {
            $msgBox = alertBox('Cadastro já existe, altere para um nome de categoria que ainda não existe!');
        }
        else{		
		$sql="UPDATE categoria SET DescricaoCategoria = ? WHERE CategoriaId = $CategoriaIds";
		if($statement = $mysqli->prepare($sql)){
			//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
			$statement->bind_param('s', $DescricaoCategoria);	
			$statement->execute();
			
		}
		$msgBox = alertBox('Alterado com sucesso!');
	}
}

// criando nova categoria
if (isset($_POST['submit'])) {
		
		$categoria	= $mysqli->real_escape_string($_POST["categoria"]);	
		$nivel		= 2;
		$sql="Select DescricaoCategoria from categoria Where DescricaoCategoria = '$categoria' AND Nivel=$nivel";
		$c= mysqli_query($mysqli, $sql);
		if (mysqli_num_rows($c) >= 1) {
            $msgBox = alertBox('Cadastro já existe');
        }else{		
		//inserindo no banco
		$sql="INSERT INTO categoria (UserId, DescricaoCategoria, Nivel) VALUES (?,?,?)";
		if($statement = $mysqli->prepare($sql)){
			$statement->bind_param('isi',$UserId, $categoria, $nivel);	
			$statement->execute();
		}
		$msgBox = alertBox("Cadastrado com sucesso!");	
	}
}
	
//Lista as categorias
$GetList = "SELECT CategoriaId, DescricaoCategoria FROM categoria WHERE Nivel = 2 AND UserId = $UserId ORDER BY DescricaoCategoria ASC";
$GetListCategoria = mysqli_query($mysqli,$GetList); 

//Buscar
if (isset($_POST['buscarbtn'])) {
	$BuscarTermo = $_POST['buscar'];
	$GetList = "SELECT CategoriaId, DescricaoCategoria FROM categoria WHERE Nivel = 2 AND UserId = $UserId  AND DescricaoCategoria
				like '%$BuscarTermo%' ORDER BY DescricaoCategoria ASC";
$GetListCategoria = mysqli_query($mysqli,$GetList); 
	
}
	
?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo 'Categoria de Despesas'; ?>	</h1>
                </div>
            </div>
			<?php if ($msgBox) { echo $msgBox; } ?>
				<a href="#new" class="btn white btn-success " data-toggle="modal"><i class="fa fa-plus"></i> <?php echo 'Nova'; ?></a>
            <div class="row">
				<div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> <?php echo 'Categorias'; ?>  
                        </div>
                        <div class="panel-body">
							<div class="pull-right">
								<form action="" method="post">
									<div class="form-group input-group col-lg-5	pull-right">
                                        <input type="text" name="buscar" placeholder="<?php echo 'Buscar'; ?>" class="form-control">
                                        <span class="input-group-btn">
                                        <button class="btn btn-primary" name="buscarbtn" type="input"><i class="fa fa-search"></i></button>
                                         </span> 
									</div>
                                </form> 
                            </div>     
                            <div class="">
                                <table class="table table-striped table-bordered table-hover" id="assetsdata">
                                    <thead>
									<tr>
										<th class="text-left"><?php echo 'Categoria'; ?></th>
										<th class="text-left"><?php echo 'Ação'; ?></th>
									</tr>
									</thead>
								<tbody>
									<?php while($col = mysqli_fetch_assoc($GetListCategoria)){ ?>
									<tr>
										<td><?php echo $col['DescricaoCategoria'];?></td>
										<td colspan="2" class="notification">
										<a href="#EditCat<?php echo $col['CategoriaId'];?>" class="" data-toggle="modal"><span class="btn btn-primary btn-xs glyphicon glyphicon-edit" data-toggle="tooltip" data-placement="left" title="" data-original-title="<?php echo $EditCategory; ?>"></span></a>
										<a href="#DeleteCat<?php echo $col['CategoriaId'];?>"  data-toggle="modal"><span class=" glyphicon glyphicon-trash btn btn-primary btn-xs" data-toggle="tooltip" data-placement="right" title="" data-original-title="<?php echo $DeleteCategories; ?>"></span></a>			
										</td>
									</tr>
								</tbody>
							<div class="modal fade" id="DeleteCat<?php echo $col['CategoriaId'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">	
                                <div class="modal-dialog">
                                    <div class="modal-content">
										<form action="" method="post">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												<h4 class="modal-title" id="myModalLabel"><?php echo 'Deseja excluir este item?'; ?></h4>
											</div>
											<div class="modal-footer">
												<input type="hidden" id="categoriaid" name="categoriaid" value="<?php echo $col['CategoriaId']; ?>" />
												<button type="input" id="submit" name="submitin" class="btn btn-primary"><?php echo 'Sim'; ?></button>
												<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo 'Cancelar'; ?></button>
                                        </form>
											</div>
                                    </div>
                                </div>
                            </div>
							<div class="modal fade" id="EditCat<?php echo $col['CategoriaId'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">	
                                <div class="modal-dialog">
                                    <div class="modal-content">
										<form action="" method="post">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												<h4 class="modal-title" id="myModalLabel"><?php echo 'Editar'; ?></h4>
											</div>
											<div class="modal-body">
												<div class="form-group">
													<label for="categoria"><?php echo 'Categoria'; ?></label>
													<input class="form-control" required  name="categoriaedit" value="<?php echo $col['DescricaoCategoria']; ?>" type="text" autofocus>
												</div>
											</div>
											<div class="modal-footer">
												<input type="hidden" id="categoriaid" name="categoriaid" value="<?php echo $col['CategoriaId']; ?>" />
												<button type="input" id="submit" name="edit" class="btn btn-primary"><?php echo 'Sim'; ?></button>
												<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo 'Cancelar'; ?></button>
                                        </form>
											</div>
                                    </div>
                                </div>
                            </div>
	                		 <?php } ?>   
						
		                
								</table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
		<div class="modal fade" id="new" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">  
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="" method="post">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title" id="myModalLabel"><?php echo 'Nova'; ?></h4>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="categoria"><?php echo 'Categoria'; ?></label>
                                <input class="form-control" required placeholder="<?php echo 'Categoria'; ?>" name="categoria" type="text" autofocus>
                            </div>
                        </div>
                        <div class="modal-footer">                     
                            <button type="submit" name="submit" class="btn btn-success"><span class=""></span>  <?php echo 'Salvar'; ?></button>
                            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo 'Cancelar'; ?></button>
                    </form>
                        </div>
                </div>             
            </div>
<script>
    $(function() {
		
     $('.notification').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })

    });
    </script>
