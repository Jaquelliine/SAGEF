<?php

//Include 
include('includes/FuncoesAuxiliar.php');
include ('includes/global.php');

// metodo de excluir 
if (isset($_GET['receitaid'])) {
		// pega o id
		$ReceitaIds = $_GET['receitaid'];	
		//faz a exclusão
		$Delete = "DELETE FROM receita WHERE ReceitaId = $ReceitaIds";
		$DeleteI = mysqli_query($mysqli,$Delete); 
		alertBox('Item excluido!');
	}
// Soma todos rendimento
$GetTodasReceitas 	 = "SELECT SUM(Valor) AS Valor FROM receita WHERE UserId = $UserId";
$GetAReceita		 = mysqli_query($mysqli, $GetTodasReceitas);
$ReceitaCol 		 = mysqli_fetch_assoc($GetAReceita);
	
//Mostra tabela com os dados de todas as receitas
$GetResumoReceita = "SELECT * from receita left join categoria on receita.CategoriaId = categoria.CategoriaId left join conta on receita.ContaId = conta.ContaId where receita.UserId = $UserId ORDER BY receita.Date DESC";
$ResumoReceita = mysqli_query($mysqli,$GetResumoReceita); 


// Buscar renda pela data.
if (isset($_POST['buscarbtndata'])) {
	$dataincial=$_POST['buscardatainicio'];
	$datafinal=$_POST['buscardatafim'];
	$GetResumoReceita = "SELECT * from receita left join categoria on receita.CategoriaId = categoria.CategoriaId left join conta on receita.ContaId = conta.ContaId
							WHERE receita.UserId = $UserId AND Date BETWEEN '$dataincial' AND '$datafinal'";
	$ResumoReceita = mysqli_query($mysqli,$GetResumoReceita); 
	
}

	
?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo 'Resumo de Rendimentos' ;?></h1>
                </div>
            </div>
			 <?php if ($msgBox) { echo $msgBox; } ?>
				<a href="index.php?page=NovaRenda" class="btn white btn-success "><i class="fa fa-plus"></i> <?php echo 'Novo'; ?></a>
				
				<input type="button" class="btn white btn-success" value="Imprimir" id="btnImprimir" onclick="CriaPDF()"/>
				<div class="pull-right">
								<form name="form1" action="" method="post">
								<div class="form-group input-group col-lg-2	pull-left">
                                     De:<input type="date" name="buscardatainicio" title="Data Inicial"  class="form-control" placeholder="Data Inicio"/>
                                </div>
								<div class="form-group input-group col-lg-2	pull-right">
                                     Até:<input type="date"  name="buscardatafim" title="Data Final" class="form-control" placeholder="Data Final"/>
									<span class="input-group-btn">
									<p> </p>
									<p> </br> </p>
									<button onclick="return validar()" class="btn btn-primary" name="buscarbtndata" type="input"><i class="fa fa-search"></i></button>
                                     </span>
							   </div>
                                </form> 
                            </div> 
							
				  <div class="row">
				  <div id="tabela">
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                           <i class="glyphicon glyphicon-stats"></i> <?php echo 'Histórico de Rendimentos' ;?>
                        </div>
                        <div class="panel-body">
						
                            <div class="">
							
							
							
                                <table class="table table-bordered table-hover table-striped" id="assetsdata">
                                    <thead>
        			                <tr>
        			                    <th class="text-left"><?php echo 'Titulo' ;?></th>
        			                    <th class="text-left"><?php echo 'Data' ;?></th>
        			                    <th class="text-left"><?php echo 'Categoria' ;?></th>
        			                    <th class="text-left"><?php echo 'Conta' ;?></th>
										<th class="text-left"><?php echo 'Descrição' ;?></th>
        			                    <th class="text-left"><?php echo 'Valor' ;?></th>

        			                </tr>
									</thead>

								<tbody>
								<?php while($col = mysqli_fetch_assoc($ResumoReceita)){ ?>
								<tr>
									<td><?php echo $col['Titulo'];?></td>
									<td><?php echo date("d/m/Y",strtotime($col['Date']));?></td>
									<td><?php echo $col['DescricaoCategoria'];?></td>
									<td><?php echo $col['NomeContaBanco'];?></td>
									<td><?php echo $col['Descricao'];?></td>
									<td><?php echo 'R$ '.number_format($col['Valor'],2,',','.');?></td>
								
									
																		
									<td  class="notification">
									<a href="index.php?page=EditarRendimento&id=<?php echo $col['ReceitaId'];?>" class="" data-toggle="modal"><span class="btn btn-primary btn-xs glyphicon glyphicon-edit" data-toggle="tooltip" data-placement="left" title="" data-original-title="<?php echo 'Editar' ;?>"></span></a>
									<a href="javascript:ExcluiRegistro(<?php echo $col['ReceitaId'];?>);"  data-toggle="modal"><span class=" glyphicon glyphicon-trash btn btn-primary btn-xs" data-toggle="tooltip" data-placement="right" title="" data-original-title="<?php echo'ExcluirReceita' ;?>"></span></button>			
									
									</td>
								</tr>
								</tbody>
							
							
							<?php } ?>   
							</table>
								<table align="right" >
									<tr >
									<td ><?php echo 'TOTAL:'.' '.'R$'.' '.number_format($ReceitaCol['Valor'],2,',','.').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'?> </td>
									</tr>
								</table>
							</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script>
	function ExcluiRegistro(reg){
		confirm("Deseja excluir esse registro?");
		if (true) {
			location.href='index.php?page=ResumoRendimentos&receitaid='+reg;
		 }
		
	}
	
	function validar() { 
	var buscardatainicio = form1.buscardatainicio.value; 
	var buscardatafim = form1.buscardatafim.value;
	if (buscardatafim == "") { 
	alert('Preencha o intervalo de datas!');
	location.href='index.php?page=ResumoRendimentos';
	form1.buscardatafim.focus();
	return false;
 } 
	if (buscardatainicio == "") { 
	alert('Preencha o intervalo de datas!');
	location.href='index.php?page=ResumoRendimentos';
	form1.buscardatainicio.focus();
	return false;
 } 
 if (buscardatainicio > buscardatafim) { 
	alert('Data inicial não pode ser maior que a data final!');
	location.href='index.php?page=ResumoRendimentos';
	form1.buscardatainicio.focus();
	return false;
 } 
 if (buscardatafim < buscardatainicio) { 
	alert('Data final não pode ser menor que a data inicial!');
	location.href='index.php?page=ResumoRendimentos';
	form1.buscardatainicio.focus();
	return false;
 } 
 
}
	
    function CriaPDF() {
        var minhaTabela = document.getElementById('tabela').innerHTML;

        var style = "<style>";
        style = style + "table {width: 100%;font: 20px Calibri;}";
        style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";

        // CRIA UM OBJETO WINDOW
        var win = window.open('', '', 'height=700,width=700');

        win.document.write('<html><head>');
        win.document.write('<title>Relatório de Rendimentos</title>');   // <title> CABEÇALHO DO PDF.
        win.document.write(style);                                     // INCLUI UM ESTILO NA TAB HEAD
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(minhaTabela);                          // O CONTEUDO DA TABELA DENTRO DA TAG BODY
        win.document.write('</body></html>');

        win.document.close(); 	                                         // FECHA A JANELA

        win.print();                                                            // IMPRIME O CONTEUDO
    }
</script>	
