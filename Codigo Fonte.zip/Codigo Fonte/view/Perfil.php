<?php

//Include 
include('includes/FuncoesAuxiliar.php');
include ('includes/global.php');

//alterar dados da conta
if(isset($_POST['change'])){
		if($_POST['email'] == '' || $_POST['nome'] == '' || $_POST['sobrenome'] == '' || $_POST['senha'] == '' || $_POST['rsenha'] == '') {
				$msgBox = alertBox('Preencha todos os campos!');
			} else if($_POST['senha'] != $_POST['rsenha']) {
				$msgBox = alertBox('Senhas não conferem. Tente Novamente!');
				
			} else {
				// passa os novos dados da conta, os dados que serão alterado
				$Email 		= $mysqli->real_escape_string($_POST['email']);
				$Senha 	= ($_POST['senha']);
				$Nome	= $mysqli->real_escape_string($_POST['nome']);
				$Sobrenome	= $mysqli->real_escape_string($_POST['sobrenome']);
				$Sexo	= $mysqli->real_escape_string($_POST['sexo']);
				
				//altera no banco os dados do usuario
				$sql="UPDATE usuario SET Nome = ?, Sobrenome = ?, Email = ?, Senha = ?, Sexo = ? WHERE UserId = $UserId";
				if($statement = $mysqli->prepare($sql)){
					$statement->bind_param('sssss', $Nome, $Sobrenome, $Email, $Senha, $Sexo);	
					$statement->execute();
				}
				$msgBox = alertBox('Conta alterada com sucesso!');
			}
	}

// Passa os dados do usuario 
$GetUsers	 	 = "SELECT Nome, Sobrenome, Email, Sexo, Senha from usuario WHERE UserId = $UserId";
$GetUserq		 = mysqli_query($mysqli, $GetUsers);
$UserInfos 		 = mysqli_fetch_assoc($GetUserq);

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo 'Configurações do Perfil'; ?>	</h1>
                </div>
            </div>
			<?php if ($msgBox) { echo $msgBox; } ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                               <i class="fa fa-bar-chart-o fa-fw"></i> <?php echo 'Informações da Conta'; ?>
                        </div>
                        <!--bloco com informações do usuario -->
                        <div class="panel-body">
							<form method="post" action="" role="form">
                                <fieldset>
                                    <div class="form-group col-lg-6">
                                        <label for="email"><?php echo 'E-mail:'; ?></label>
                                        <?php echo $UserInfos['Email'];?>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="email"><?php echo 'Nome Completo:'; ?></label>
                                        <?php echo $UserInfos['Nome'].' '.$UserInfos['Sobrenome'];?>
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label for="sexo"><?php echo 'Sexo:'; ?></label>
                                        <?php echo $UserInfos['Sexo']; ?>
                                    </div>
                                    <hr>

                                </fieldset>
                            </form>
						</div>
					</div>
							
					
					<div class="panel panel-primary">
						<div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> <?php echo 'Alterar Informações'; ?>
                        </div>
                        <!-- bloco com campos para alterar os dados do usuario -->
                        <div class="panel-body">
							<form method="post" action="" role="form">
								<fieldset>
									<div class="form-group col-lg-6">
										<label for="email"><?php echo 'E-mail'; ?></label>
										<input class="form-control"  required placeholder="<?php echo 'E-mail'; ?>" name="email" type="email"  value="<?php echo $UserInfos['Email'];?>" autofocus>
									</div>
									<div class="form-group col-lg-6">
										<label for="email"><?php echo 'Nome'; ?></label>
										<input class="form-control"  required placeholder="<?php echo 'Nome'; ?>" value="<?php echo $UserInfos['Nome'];?>" name="nome" type="text" >
									</div>
									<div class="form-group col-lg-6">
										<label for="email"><?php echo 'Sobrenome'; ?></label>
										<input class="form-control"  required placeholder="<?php echo 'Sobrenome'; ?>" name="sobrenome"  value="<?php echo $UserInfos['Sobrenome'];?>" type="text" >
									</div>
									<div class="form-group col-lg-6">
										<label for="email"><?php echo 'Sexo'; ?></label>
										<select class="form-control bold"  name="sexo">
											<option value="<?php echo $UserInfos['Sexo'];?>" selected="" ><?php echo $UserInfos['Sexo'];?></option>
											<option value="Feminino">Feminino</option>
											<option value="Masculino">Masculino</option></select>
										</select>
									</div>
									<div class="form-group col-lg-6">
										<label for="senha"><?php echo 'Senha'; ?></label>
										<input class="form-control"  placeholder="<?php echo 'Senha'; ?>" name="senha" type="password" value="">
									</div>
									<div class="form-group col-lg-6">
										<label for="senha"><?php echo 'Repita a senha'; ?></label>
										<input class="form-control"  placeholder="<?php echo 'Repita a senha'; ?>" name="rsenha" type="password" value="">
									</div>
								<div class="form-group col-lg-4 text-center">
									<button type="submit" name="change" class="btn btn-success btn-block"><span class="glyphicon glyphicon-log-in"></span>  <?php echo 'Salvar'; ?></button>
								</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
        </div>
       
<script>
    $(function() {
		
     $('.notification').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })

    });
    </script>
