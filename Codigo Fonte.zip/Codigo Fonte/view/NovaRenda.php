<?php

//Include 
include('includes/FuncoesAuxiliar.php');


//verifica os dados antes de salvar no banco
if(isset($_POST['receita'])){
		$iuser			= $_SESSION['UserId'];
		$ititulo 			= $mysqli->real_escape_string($_POST["ititulo"]);
		$icategoria		= $mysqli->real_escape_string($_POST["icategoria"]);
		$iconta		= $mysqli->real_escape_string($_POST["iconta"]);
		$idescricao	= $mysqli->real_escape_string($_POST["idescricao"]);
		$idate			= $mysqli->real_escape_string($_POST["idate"]);
		$ivalor		= $mysqli->real_escape_string(clean($_POST["ivalor"]));
		// verifica se o titulo e o valor nao estão vazios
        if($ititulo == '' OR $ivalor == '' ) {
                $msgBox = alertBox('Titulo ou valor não preenchidos. Favor preencha os campos!');
            } else{
		// valor não pode ser menor que zero
        if($ivalor < 0){
            $msgBox = alertBox('Valor não pode ser menor que zero');
        }else{
		//insere os dados no banco, se tiver passado nos requisitos anteriores
		$sql="INSERT INTO receita (UserId, Titulo, Date, CategoriaId, ContaId, Valor, Descricao) VALUES (?,?,?,?,?,?,?)";
		if($statement = $mysqli->prepare($sql)){
			$statement->bind_param('issiiss',$iuser, $ititulo, $idate, $icategoria, $iconta, $ivalor, $idescricao);	
			$statement->execute();
		}
		$msgBox = alertBox(	'Salvo com sucesso!');
        }
     }
	}
?>        
      
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
				    <h1 class="page-header"><?php echo 'Novo Rendimento' ;?></h1>
                </div>
            </div>
			
			 <?php if ($msgBox) { echo $msgBox; } ?>
            <div class="row">                 
                <div class="col-lg-12 ">
					<div class="panel panel-primary">
                        <div class="panel-heading">
                           <i class="fa fa-plus"></i> <?php echo 'Renda' ;?>
                        </div>
                            <div class="panel-body">
                                <form role="form" method="post" action="">
                                    <fieldset>
                                    <div class="form-group col-lg-6">
								        <label for="ititulo"><?php echo 'Titulo' ;?></label>
                                        <input class="form-control"  required placeholder="<?php echo 'Titulo' ;?>" name="ititulo" type="text" autofocus>
                                    </div>
                                    <div class="form-group col-lg-5">
										 <label for="ivalor" class="control-label"><?php echo 'Valor' ;?></label> 
											 <div class="input-group">                                     
												 <input class="form-control" required placeholder="<?php echo 'Valor' ;?>"  id="ivalor" name="ivalor" type="text" value="">
											 </div>
									</div>
									<div class="form-group col-lg-6">
                                        <label for="icategoria"><?php echo 'Categoria' ;?></label>
                                        <select name="icategoria" class="form-control">
										<?php while($col = mysqli_fetch_assoc($receita)){ ?>
                                            <option value="<?php echo $col['CategoriaId'];?>"><?php echo $col['DescricaoCategoria'];?></option>
                                            <?php } ?>
                                        </select>
                                    </div>                             
									<div class="form-group col-lg-4">
                                         <label for="iconta"><?php echo 'Conta' ;?></label>
                                        <select name="iconta" class="form-control">
                                            <?php while($col = mysqli_fetch_assoc($ContaReceita)){ ?>
                                            <option value="<?php echo $col['ContaId'];?>"><?php echo $col['NomeContaBanco'];?></option>
                                            <?php } ?>
                                        </select>
									</div>
									
									<div class="form-group col-lg-4">
                                         <label for="iconta"><?php echo 'Data' ;?></label>
                                       <input name="idate" class="form-control" type="date"  value="<?php echo date("d-m-Y");?>">
											</input>
									</div>
									
                                    <div class="form-group col-lg-6">
								        <label for="idescricao"><?php echo 'Descição' ;?></label>
                                        <input class="form-control"  required placeholder="<?php echo 'Descrição' ;?>" name="idescricao" type="text" autofocus>
                                    </div>                      
									</fieldset>
                            </div>
									<div class="panel-footer">
										<button type="submit" name="receita" class="btn btn-success btn-block"><span class="glyphicon glyphicon-log-in"></span>  <?php echo 'Salvar' ;?></button>
								</form>
									</div>
                    </div>
                </div>
             </div>
        </div>
 <script>
$(document).on('keyup', '#ivalor', function() {
    var x = $(this).val();
    $(this).val(x.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ","));
});
 </script>