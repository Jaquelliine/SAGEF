<?php
$msgBox = '';
//Include 
include('includes/FuncoesAuxiliar.php');
include ('includes/global.php');
include ('includes/db.php');

//excluir categoria de conta
if(isset($_POST['submitin'])){
		$CategoriaIds = $_POST['categoriaid'];
		$Delete = "DELETE FROM conta WHERE ContaId = $CategoriaIds";
		$DeleteI = mysqli_query($mysqli,$Delete); 
		
		$msgBox = alertBox('Conta Excluida');
	}

//Editar categoria
if(isset($_POST['edit'])){
		$CategoriaIds = $_POST['categoriaid'];
		$DescricaoCategoria = $_POST['categoriaedit'];
		$sql="Select NomeContaBanco from conta Where NomeContaBanco = '$DescricaoCategoria'";
		$c= mysqli_query($mysqli, $sql);
		if (mysqli_num_rows($c) >= 1) {
            $msgBox = alertBox('Cadastro já existe, altere para um nome de categoria que ainda não existe!');
        }
        else{				
		$sql="UPDATE conta SET NomeContaBanco = ? WHERE ContaId = $CategoriaIds";
		if($statement = $mysqli->prepare($sql)){
			//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
			$statement->bind_param('s', $DescricaoCategoria);	
			$statement->execute();
			
		}
		$msgBox = alertBox('Alterada com sucesso!');
	}
}


// criar nova categoria de conta
if (isset($_POST['submit'])) {
	
		$nomeconta	= $mysqli->real_escape_string($_POST['conta']);	
		
		$sql="Select NomeContaBanco from conta Where NomeContaBanco = '$nomeconta'";
		$c= mysqli_query($mysqli, $sql);
        if (mysqli_num_rows($c) >= 1) {
            $msgBox = alertBox('Cadastro já existe');
        }
        else{		
		//insere
		$sql="INSERT INTO conta (UserId, NomeContaBanco) VALUES (?,?)";
		if($statement = $mysqli->prepare($sql)){
			$statement->bind_param('is',$UserId, $nomeconta);	
			$statement->execute();
		}	
		$msgBox = alertBox($nomeconta.' cadastrada com sucesso!');
			//se não
		}
		}
	
//Lista as categorias
$GetList = "SELECT ContaId, NomeContaBanco FROM conta WHERE UserId = $UserId";
$GetListCategoria = mysqli_query($mysqli,$GetList); 

// Buscar
if (isset($_POST['buscarbtn'])) {
	$BuscarTermo = $_POST['buscar'];
	$GetList = "SELECT ContaId, NomeContaBanco FROM conta WHERE UserId = $UserId  AND NomeContaBanco
				like '%$BuscarTermo%' ORDER BY NomeContaBanco ASC";
$GetListCategoria = mysqli_query($mysqli,$GetList); 	
}

	
?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo 'Categoria de Conta/Banco'; ?>	</h1>
                </div>
            </div>
			<?php if ($msgBox) { echo $msgBox; } ?>
			<a href="#new" class="btn white btn-success " data-toggle="modal"><i class="fa fa-plus"></i> <?php echo 'Novo'; ?></a>
            <div class="row">
				<div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-tags"></i> <?php echo 'Conta/Banco'; ?> 
                        </div>
                        <div class="panel-body">
							<div class="pull-right">
								<form action="" method="post">
									<div class="form-group input-group col-lg-5	pull-right">
                                            <input type="text" name="buscar" placeholder="<?php echo 'Buscar'; ?>" class="form-control">
                                            <span class="input-group-btn">
                                            <button class="btn btn-primary" name="buscarbtn" type="input"><i class="fa fa-search"></i></button>
                                            </span> 
									</div>
                                </form> 
                            </div>     
                            <div class="">
                                <table class="table table-bordered table-hover table-striped" id="assetsdata">
                                    <thead>
									<tr>
										<th class="text-left"><?php echo 'Conta/Banco'; ?></th>
										<th class="text-left"><?php echo 'Ação'; ?></th>
									</tr>
									</thead>
								<tbody>
								<?php while($col = mysqli_fetch_assoc($GetListCategoria)){ ?>
									<tr>
										<td><?php echo $col['NomeContaBanco'];?></td>
										<td colspan="2" class="notification">
										<a href="#EditCat<?php echo $col['ContaId'];?>" class="" data-toggle="modal"><span class="btn btn-primary btn-xs glyphicon glyphicon-edit" data-toggle="tooltip" data-placement="left" title="" data-original-title="<?php echo 'Editar'; ?>"></span></a>
										<a href="#DeleteCat<?php echo $col['ContaId'];?>"  data-toggle="modal"><span class=" glyphicon glyphicon-trash btn btn-primary btn-xs" data-toggle="tooltip" data-placement="right" title="" data-original-title="<?php echo 'Excluir'; ?>"></span></a>			
										</td>
									</tr>
								</tbody>
							<div class="modal fade" id="DeleteCat<?php echo $col['ContaId'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">	
                                <div class="modal-dialog">
                                    <div class="modal-content">
										<form action="" method="post">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												<h4 class="modal-title" id="myModalLabel"><?php echo 'Deseja excluir este item?'; ?></h4>
											</div>
											<div class="modal-footer">
												<input type="hidden" id="categoriaid" name="categoriaid" value="<?php echo $col['ContaId']; ?>" />
												<button type="input" id="submit" name="submitin" class="btn btn-primary"><?php echo 'Sim'; ?></button>
												<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo 'Cancelar'; ?></button>
                                        </form>
											</div>
                                    </div>
                                </div>
                            </div>
							<div class="modal fade" id="EditCat<?php echo $col['ContaId'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">	
                                <div class="modal-dialog">
                                    <div class="modal-content">
										<form action="" method="post">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												<h4 class="modal-title" id="myModalLabel"><?php echo 'Editar'; ?></h4>
											</div>
											<div class="modal-body">
												<div class="form-group">
													<label for="categoria"><?php echo 'Conta/Banco'; ?></label>
													<input class="form-control" required  name="categoriaedit" value="<?php echo $col['NomeContaBanco']; ?>" type="text" autofocus>
												</div>
											</div>
											<div class="modal-footer">
												<input type="hidden" id="categoriaid" name="categoriaid" value="<?php echo $col['ContaId']; ?>" />
												<button type="input" id="submit" name="edit" class="btn btn-primary"><?php echo 'Salvar'; ?></button>
												<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo 'Cancelar'; ?></button>
                                        </form>
											</div>
                                    </div>
                                </div>
                            </div>				
	                		 <?php } ?>   
								</table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
		<div class="modal fade" id="new" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">  
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="" method="post">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title" id="myModalLabel"><?php echo 'Nova Conta/Banco'; ?></h4>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="categoria"><?php echo 'Conta/Banco'; ?></label>
                                <input class="form-control" required placeholder="<?php echo 'Conta/Banco'; ?>" name="conta" type="text" autofocus>
                            </div>
                        </div>
                        <div class="modal-footer">                 
                            <button type="submit" name="submit" class="btn btn-success"><span class=""></span>  <?php echo 'Salvar'; ?></button>
                            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo 'Cancelar'; ?></button>
                    </form>
                        </div>
                </div>
            </div>
<script>


    $(function() {
		
     $('.notification').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })

    });
    </script>
