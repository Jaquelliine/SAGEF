<?php

// include connection to database
include ('includes/db.php');


// Get User Info
$UserId=$_SESSION['UserId'];
$GetUserInfo = "SELECT * FROM usuario WHERE UserId = $UserId";
$UserInfo = mysqli_query($mysqli, $GetUserInfo);
$ColUser = mysqli_fetch_assoc($UserInfo);



//category for income
$Getreceita = "SELECT CategoriaId, UserId, DescricaoCategoria, Nivel FROM categoria WHERE (UserId = 0 OR UserId = $UserId) AND Nivel = 1";
$receita = mysqli_query($mysqli,$Getreceita); 

					
// Category for Expense
$Getexpense = "SELECT CategoriaId, UserId, DescricaoCategoria, Nivel FROM categoria WHERE (UserId = 0 OR UserId = $UserId) AND Nivel = 2";
$despesa = mysqli_query($mysqli,$Getexpense); 

// Category for account Expense
$GetAccountExpense = "SELECT ContaId, UserId, NomeContaBanco FROM conta WHERE UserId = 0 OR UserId = $UserId";
$AccountExpense = mysqli_query($mysqli,$GetAccountExpense); 

// Category for account Income
$GetContaReceita = "SELECT ContaId, UserId, NomeContaBanco FROM conta WHERE UserId = 0 OR UserId = $UserId";
$ContaReceita = mysqli_query($mysqli,$GetContaReceita); 


/* CHART QUERY HERE
 * 
 */
// get data based from account
$GetAccountDount = "SELECT conta.NomeContaBanco, sum(receita.Valor) AS Valor FROM conta, receita where conta.ContaId=receita.ContaId AND receita.UserId= $UserId group by conta.NomeContaBanco";
$Dount = mysqli_query($mysqli, $GetAccountDount);

$GetAccountDounts = "SELECT categoria.DescricaoCategoria, SUM(despesa.valor) AS Valor FROM categoria, despesa where categoria.CategoriaId=despesa.CategoriaId AND categoria.Nivel = 2 AND despesa.UserId = $UserId GROUP BY despesa.CategoriaId";
$Dounts = mysqli_query($mysqli, $GetAccountDounts);

// income vs expense by month

/* $GetAccountDountdate = "SELECT AmountExpense, AmountIncome
					  FROM (  SELECT  UserId, 
                      SUM(Valor) AS AmountExpense, vencimento
                      FROM despesa WHERE MONTH(Dates) = MONTH(current_date())
				      GROUP BY UserId) AS b
					  JOIN ( SELECT  UserId,
                      SUM(Valor) AS AmountIncome, date
				      FROM receita WHERE MONTH(Date) = MONTH(current_date())
					  GROUP BY UserId) AS a
					  ON b.UserId = a.UserId
					  WHERE b.UserId = $UserId";
$Dountvsdate 	 = mysqli_query($mysqli, $GetAccountDountdate);
$ColsDounatMonth = mysqli_fetch_assoc($Dountvsdate);


*/



// get data based from budget
$Year 	= date("Y");
$Month  = date("m");



/* For PDF Report */

//Mostra o resumo de receitas
$GetResumoReceita = "SELECT * from receita left join categoria on receita.CategoriaId = categoria.CategoriaId left join conta on receita.ContaId = conta.ContaId where receita.UserId = $UserId ORDER BY receita.Date DESC";
$IncomeReport = mysqli_query($mysqli,$GetResumoReceita); 



?>
