<?php

session_start();
//Include Database

include('db.php');
//Include 
include('FuncoesAuxiliar.php');


// Get User Info
$UserId=$_SESSION['UserId'];
$GetUserInfo = "SELECT * FROM usuario WHERE UserId = $UserId";
$UserInfo = mysqli_query($mysqli, $GetUserInfo);
$ColUser = mysqli_fetch_assoc($UserInfo);
	
// fetch data to calender
$query 				   = "select * from receita where UserId = $UserId ";
$assetstocalender      = mysqli_query($mysqli, $query);
$events = array();
$sum = 0;
while ($row = mysqli_fetch_assoc($assetstocalender)) {
    $start = $row['Date'];
    $end   = $row['Date'];
    $valor = 'R$ '.number_format($row['Valor']);
    $titulo = $row['Titulo'];
    $sum+= $row['Valor'];
    
    $eventsArray['titulo'] = $titulo;
    $eventsArray['start'] = $start;
    $eventsArray['end'] = $end;
    $eventsArray['names'] = $valor;
    $events[] = $eventsArray;
}
$eventsArray['sum'] = $sum;
echo json_encode($events);	
//echo $sum;	
	
?>
