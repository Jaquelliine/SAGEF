<?php
include ('includes/notification.php');
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Gerenciador financeiro</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">
    <link href="css/plugins/dataTables.bootstrap.css" rel="stylesheet">
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="js/plugins/fullcalender/fullcalendar.css" rel="stylesheet">
     <link href="css/datepicker.css" rel="stylesheet">
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <script src="js/jquery-1.11.0.js"></script>
     <script src="js/plugins/metisMenu/metisMenu.js"></script>
	<!--Load the AJAX API-->
	<script type="text/javascript" src="https://www.google.com/jsapi"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
</head>

<body>

    <div id="wrapper">

      
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="headmain">
            <div class="navbar-header">
                
               <a class="navbar-brand" href="index.php"> <img src="logo/logo.png" ></a></img>
            </div>
           

            <ul class="nav navbar-top-links navbar-right">
                <li>
                     <?php 
                    echo 'Olá';?>, 
                    <?php 
                    echo $ColUser['Nome'];?>
                </li>
                
               
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        
                        <li> <a <?php ActiveClass("index.php?page=Perfil");?> href="index.php?page=Perfil"><i class="fa fa-gear fa-fw"></i> <?php echo 'Perfil';?></a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="index.php?action=logout"><i class="fa fa-sign-out fa-fw"></i> <?php echo 'Sair';?></a>
                        </li>
                    </ul>
                </li>
            </ul>
           
        </div>
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav font-sidebar" id="side-menu">
                      
                        <li>
                            <a <?php ActiveClass("index");?> href="index.php"><i class="glyphicon glyphicon-home"></i>  <?php echo 'Painel Resumo';?><span class="fa arrow"></a>
                        </li>
                        <li>
                            <a <?php ActiveClass("index.php?page=ResumoRendimentos");?> href="index.php?page=ResumoRendimentos"><i class="glyphicon glyphicon-stats"></i>  <?php echo 'Rendimentos';?><span class="fa arrow"></span></a>
                        </li>
                        <li>
                            <a <?php ActiveClass("index.php?page=ResumoDespesas");?> href="index.php?page=ResumoDespesas" ><i class="glyphicon glyphicon-list-alt"></i> <?php echo 'Despesas';?><span class="fa arrow"></span></a>
                        <li>    
                         
                        </li>                           
                        </li>
                       
                        
                    <li>
                        <a class="parent" href="javascript:void(0)"><i class="fa fa-gears"> </i> <?php echo 'Categorias';?><span class="fa arrow"></a>
                        <ul class="nav nav-second-level" id="subitem">
                                <li>
                                    <a <?php ActiveClass("index.php?page=CategoriaDespesa");?> href="index.php?page=CategoriaDespesa"><i class="fa fa-caret-right"></i> <?php echo 'Categoria de Despesa';?></a>
                                </li>
                                <li>
                                    <a <?php ActiveClass("index.php?page=CategoriaRendimentos");?> href="index.php?page=CategoriaRendimentos"><i class="fa fa-caret-right"></i> <?php echo 'Categoria de Receita';?></a>
                                </li>
								<li>
                                    <a <?php ActiveClass("index.php?page=CategoriaConta");?> href="index.php?page=CategoriaConta"> <i class="fa fa-caret-right"></i> <?php echo 'Categoria de Conta';?></a>
                                </li>
                                
                        </ul>
                    </li>

                    
                       <li>
                            <a <?php ActiveClass("index.php?page=Perfil");?> href="index.php?page=Perfil"><i class="fa fa-user"> </i> <?php echo 'Perfil';?><span class="fa arrow"></a>
                        </li>
                        
                         <li>
                            <a href="index.php?action=logout"><i class="glyphicon glyphicon-log-out"></i>  <?php echo 'Sair';?><span class="fa arrow"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

<script>

$(document).ready(function () {
    $(this).parent().addClass("collapse");
    $(".parent").on('click', function () {
        $(this).parent().find("#subitem").slideToggle();
    });
});

</script>
      
