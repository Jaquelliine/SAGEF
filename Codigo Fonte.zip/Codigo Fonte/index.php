<?php session_start();


function ActiveClass($requestUri)
{
    $current_file_name = basename($_SERVER['REQUEST_URI'], ".php");

    if ($current_file_name == $requestUri)
        echo 'class="active"';
}
		
		//verifica se tem um login efetuado
		if (!isset($_SESSION['UserId'])) {
			header ('Location: login.php');
			exit;
		}

		// Logout
		if (isset($_GET['action'])) {
			$action = $_GET['action'];
			if ($action == 'logout') {
				session_destroy();
				header('Location: login.php');
			}
		}



 //Link para as paginas
if (isset($_GET['page']) && $_GET['page'] == 'NovaRenda') {
            $page = 'NovaRenda';
		} else if (isset($_GET['page']) && $_GET['page'] == 'NovaDespesa') {
            $page = "NovaDespesa";
        } else if (isset($_GET['page']) && $_GET['page'] == 'ResumoRendimentos') {
            $page = "ResumoRendimentos";
        } else if (isset($_GET['page']) && $_GET['page'] == 'CategoriaRendimentos') {
            $page = "CategoriaRendimentos";
        } else if (isset($_GET['page']) && $_GET['page'] == 'CategoriaDespesa') {
            $page = "CategoriaDespesa";
        } else if (isset($_GET['page']) && $_GET['page'] == 'CategoriaConta') {
            $page = "CategoriaConta";
        } else if (isset($_GET['page']) && $_GET['page'] == 'EditarRendimento') {
            $page = "EditarRendimento";
        } else if (isset($_GET['page']) && $_GET['page'] == 'Perfil') {
            $page = "Perfil";
        } else if (isset($_GET['page']) && $_GET['page'] == 'ResumoDespesas') {
            $page = "ResumoDespesas";
        } else if (isset($_GET['page']) && $_GET['page'] == 'EditarDespesa') {
            $page = "EditarDespesa";
		} else if (isset($_GET['page']) && $_GET['page'] == 'ReportPdf') {
            $page = "ReportPdf";
        } else {
            $page = 'PainelResumo';
        }



include('includes/global.php');


include('includes/header.php'); 


$msgBox	="";

if (file_exists('view/'.$page.'.php')) {
            // carrega a pagina
            include('view/'.$page.'.php');
        } else {
            // se não mensagem de erro
          
            echo '
                    <div class="wrapper">
                        <h3>Err</h3>
                        <div class="alertMsg default">
                            <i class="icon-warning-sign"></i> A pagina "'.$page.'" não foi encontrada.
                        </div>
                    </div>
                ';
        }

        include('includes/footer.php');
  

?>
