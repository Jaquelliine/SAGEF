<?php
session_start();


$msgBox = '';


//Include
include ('includes/db.php');

//Include 
include ('includes/FuncoesAuxiliar.php');

//User Login

if (isset($_POST['login'])) {
    if ($_POST['email'] == '') {
        $msgBox = alertBox('Informe o e-mail!');
    } else
        if ($_POST['senha'] == '') {
            $msgBox = alertBox('Informe a senha!');

        } else {
            // Get User Info
            $Email = $mysqli->real_escape_string($_POST['email']);
            $Senha = $_POST['senha'];

            if ($stmt = $mysqli->prepare("SELECT UserId, Nome, Sobrenome, Email, Senha, Sexo from usuario WHERE Email = ? AND Senha = ? ")) {
                $stmt->bind_param("ss", $Email, $Senha);
                $stmt->execute();
                $stmt->bind_result($UserId_, $Nome_, $Sobrenome_, $Email_, $Senha_, $Sexo_);
                $stmt->store_result();
                $stmt->fetch();
                if ($num_of_rows = $stmt->num_rows >= 1) {
                    session_start();
                    $_SESSION['UserId'] = $UserId_;
                    $_SESSION['Nome'] = $Nome_;
                    $_SESSION['Sobrenome'] = $Sobrenome_;
                    $_SESSION['Sexo'] = $Sexo_;
                    $UserIds = $_SESSION['UserId'];


                    // Generate default Category for New User
                    $a = "SELECT DescricaoCategoria FROM categoria WHERE UserId = $UserIds";
                    $b = mysqli_query($mysqli, $a);

                    if (mysqli_num_rows($b) >= 1) {
                      echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
                    } else {
                        $c = "INSERT INTO categoria(UserId, DescricaoCategoria, Nivel) VALUES ($UserIds, 'Salario', 1), ($UserIds, 'Hora Extra', 1), ($UserIds, 'Alimentação', 2),
												 ($UserIds, ' Transporte', 2), ($UserIds, 'Saúde', 2)";
                        $d = mysqli_query($mysqli, $c);
                    }
                    echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
                } else {
                    $msgBox = alertBox('Dados inválidos!');
                }
            }
        }

}
?>




<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Gerenciador financeiro | Login</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>

<body class="login">

    <div class="container">
        <div class="row">
		<div class="col-md-6 col-md-offset-3">
                <div class="logo-grande">
                    <img src="logo/logoGrande.png"></img>
                </div>
            </div>
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title text-center"><span class="glyphicon glyphicon-lock"></span>  <?php echo'Login'; ?></h3>
                    </div>
                    <div class="panel-body">
						<?php if ($msgBox) {    echo $msgBox;} ?>
                        <form method="post" action="" role="form">
                            <fieldset>
                                <div class="form-group">
                                    <label for="email"><?php echo 'E-mail'; ?></label>
                                    <input class="form-control"  placeholder="<?php echo'E-mail'; ?>" name="email" type="email" autofocus>
                                </div>
                                <div class="form-group">
                                     <label for="senha"><?php echo 'Senha'; ?></label>
                                    <input class="form-control"  placeholder="<?php echo'Senha'; ?>" name="senha" type="password" value="">
                               </div>
                               
                               <hr>
                                <button type="submit" name="login" class="btn btn-success btn-block"><span class="glyphicon glyphicon-log-in"></span>  <?php echo'Entrar'; ?></button>                                 <hr>
                            <a href="signUp.php" ><span class="esquerda"> <?php echo 'Criar Conta?'; ?></span></a>
							<a href = "recuperaSenha.php"><span class="direita"><?php echo 'Esqueceu a senha?';?></span></a>
                            
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
       
    </div>

    <!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/plugins/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>

</body>

</html>
